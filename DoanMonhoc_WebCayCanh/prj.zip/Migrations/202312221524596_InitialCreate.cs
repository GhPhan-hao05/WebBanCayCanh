﻿namespace DoanMonhoc_WebCayCanh.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.OrderDetails",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        OrderId = c.Int(nullable: false),
                        ProductId = c.Int(nullable: false),
                        Count = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.OrderHeaders", t => t.OrderId, cascadeDelete: true)
                .ForeignKey("dbo.Products", t => t.ProductId, cascadeDelete: true)
                .Index(t => t.OrderId)
                .Index(t => t.ProductId);
            
            CreateTable(
                "dbo.OrderHeaders",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        OrderDate = c.DateTime(),
                        OrderTotal = c.Double(nullable: false),
                        OrderStatus = c.String(),
                        PaymentDate = c.DateTime(),
                        UserId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Users", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.Users",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        UserName = c.String(),
                        UserPassword = c.String(),
                        Name = c.String(),
                        Address = c.String(),
                        Phone = c.String(),
                        Role = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.UserRoleMappings",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        UserID = c.Int(nullable: false),
                        RoleID = c.Int(nullable: false),
                        RoleMaster_ID = c.Int(),
                    })
                .PrimaryKey(t => t.ID)
                .ForeignKey("dbo.RoleMasters", t => t.RoleMaster_ID)
                .ForeignKey("dbo.Users", t => t.UserID, cascadeDelete: true)
                .Index(t => t.UserID)
                .Index(t => t.RoleMaster_ID);
            
            CreateTable(
                "dbo.RoleMasters",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        RoleName = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Products",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        NameProduct = c.String(nullable: false),
                        ShortDescribe = c.String(nullable: false),
                        Status = c.String(nullable: false),
                        Price = c.Double(nullable: false),
                        Image = c.String(),
                        Source = c.String(nullable: false),
                        IdType = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.TypeProducts", t => t.IdType, cascadeDelete: true)
                .Index(t => t.IdType);
            
            CreateTable(
                "dbo.TypeProducts",
                c => new
                    {
                        IdType = c.Int(nullable: false, identity: true),
                        TenLoai = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.IdType);
            
            CreateTable(
                "dbo.ShoppingCarts",
                c => new
                    {
                        Id = c.Int(nullable: false),
                        ProductId = c.Int(nullable: false),
                        Count = c.Int(nullable: false),
                        UserId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Products", t => t.Id)
                .ForeignKey("dbo.Users", t => t.UserId, cascadeDelete: true)
                .Index(t => t.Id)
                .Index(t => t.UserId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ShoppingCarts", "UserId", "dbo.Users");
            DropForeignKey("dbo.ShoppingCarts", "Id", "dbo.Products");
            DropForeignKey("dbo.OrderDetails", "ProductId", "dbo.Products");
            DropForeignKey("dbo.Products", "IdType", "dbo.TypeProducts");
            DropForeignKey("dbo.OrderDetails", "OrderId", "dbo.OrderHeaders");
            DropForeignKey("dbo.OrderHeaders", "UserId", "dbo.Users");
            DropForeignKey("dbo.UserRoleMappings", "UserID", "dbo.Users");
            DropForeignKey("dbo.UserRoleMappings", "RoleMaster_ID", "dbo.RoleMasters");
            DropIndex("dbo.ShoppingCarts", new[] { "UserId" });
            DropIndex("dbo.ShoppingCarts", new[] { "Id" });
            DropIndex("dbo.Products", new[] { "IdType" });
            DropIndex("dbo.UserRoleMappings", new[] { "RoleMaster_ID" });
            DropIndex("dbo.UserRoleMappings", new[] { "UserID" });
            DropIndex("dbo.OrderHeaders", new[] { "UserId" });
            DropIndex("dbo.OrderDetails", new[] { "ProductId" });
            DropIndex("dbo.OrderDetails", new[] { "OrderId" });
            DropTable("dbo.ShoppingCarts");
            DropTable("dbo.TypeProducts");
            DropTable("dbo.Products");
            DropTable("dbo.RoleMasters");
            DropTable("dbo.UserRoleMappings");
            DropTable("dbo.Users");
            DropTable("dbo.OrderHeaders");
            DropTable("dbo.OrderDetails");
        }
    }
}
