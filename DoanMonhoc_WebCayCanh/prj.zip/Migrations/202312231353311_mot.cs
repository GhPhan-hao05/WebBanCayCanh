﻿namespace DoanMonhoc_WebCayCanh.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class mot : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.OrderHeaders", "TenNguoiNhan", c => c.String());
            AddColumn("dbo.OrderHeaders", "DiaChiNhan", c => c.String());
            AddColumn("dbo.OrderHeaders", "SoDTNguoiNhan", c => c.String());
            DropColumn("dbo.OrderHeaders", "PaymentDate");
        }
        
        public override void Down()
        {
            AddColumn("dbo.OrderHeaders", "PaymentDate", c => c.DateTime());
            DropColumn("dbo.OrderHeaders", "SoDTNguoiNhan");
            DropColumn("dbo.OrderHeaders", "DiaChiNhan");
            DropColumn("dbo.OrderHeaders", "TenNguoiNhan");
        }
    }
}
