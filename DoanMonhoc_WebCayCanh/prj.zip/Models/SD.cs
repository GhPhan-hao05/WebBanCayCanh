﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DoanMonhoc_WebCayCanh.Models
{
	public static class SD
	{
		

		public const string ChuaThanhToan = "Chua Thanh Toan";
		public const string DaThanhToan = "Da Thanh Toan";
		public const string ChoVanChuyen = "Cho Van Chuyen";
		public const string DaHoanThanh = "Da Hoan Thanh";
		public const int iduser = 0;

	}
}