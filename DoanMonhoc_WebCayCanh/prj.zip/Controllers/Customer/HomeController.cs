﻿using DoanMonhoc_WebCayCanh.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DoanMonhoc_WebCayCanh.Controllers
{
	public class HomeController : Controller
	{
		private readonly ShopDBContext db = new ShopDBContext();

		public ActionResult Index()
		{
			var allprd = from all in db.Products select all;
			return View(allprd.ToList());
		}
		public ActionResult Details(int id)
		{
			var detail = db.Products.FirstOrDefault(p => p.Id == id);
			return View(detail);
		}



		public ActionResult Contact()
		{
			ViewBag.Message = "Your contact page.";

			return View();
		}
	}
}