﻿using DoanMonhoc_WebCayCanh.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace DoanMonhoc_WebCayCanh.Controllers.Identity
{
    public class AccountController : Controller
    {
		private readonly ShopDBContext context = new ShopDBContext();
		// GET: Account
		public ActionResult Index()
        {
            return View();
        }
		public ActionResult Login()
		{
			return View();
		}
		public ActionResult CreateRole()
		{
			return View();
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public ActionResult CreateRole(RoleMaster role)
		{
			if (ModelState.IsValid)
			{
				context.RoleMasters.Add(role);
				context.SaveChanges();
				return RedirectToAction("Login");
			}
			return View(role);
		}

		[HttpPost]
		public ActionResult Login(UserModel model)
		{
			
			{

				bool IsValidUser = context.Users.Any(user => user.UserName.ToLower() == model.UserName.ToLower() && user.UserPassword == model.UserPassword);
				var currentUser = context.Users.FirstOrDefault(user => user.UserName.ToLower() == model.UserName.ToLower() && user.UserPassword == model.UserPassword);
				if (IsValidUser)
				{
					FormsAuthentication.SetAuthCookie(model.UserName, false);


					HttpCookie cookie = new HttpCookie("UserId", currentUser.ID.ToString());
					Response.Cookies.Add(cookie);

					
					return RedirectToAction("Index", "Product");

				}
				ModelState.AddModelError("", "invalid Username or Password");
				return View();
			}
		}

		public ActionResult Signup()
		{
			User newUser = new User(){};

			newUser.RoleList = context.RoleMasters.ToList().Select(
			i => new SelectListItem
			{
				Text = i.RoleName,
				Value = i.RoleName
			});


			return View(newUser);
		}
		[HttpPost]
		public ActionResult Signup(User model)
		{
			
			{
				UserRoleMapping temp = new UserRoleMapping();
				var tempRole = context.RoleMasters.FirstOrDefault(t => t.RoleName == model.Role);
				temp.RoleID = tempRole.ID;
				temp.UserID = model.ID;
				context.UserRoleMappings.Add(temp);
				context.Users.Add(model);
				context.SaveChanges();

			}
			return RedirectToAction("Login");
		}

		public ActionResult Logout()
		{
			FormsAuthentication.SignOut();
			return RedirectToAction("Login");

		}
	}
}