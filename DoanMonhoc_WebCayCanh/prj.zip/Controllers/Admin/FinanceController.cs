﻿using DoanMonhoc_WebCayCanh.Models;
using DoanMonhoc_WebCayCanh.Models.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DoanMonhoc_WebCayCanh.Controllers.Admin
{
    public class FinanceController : Controller
    {
		//finance se luu nhieu ordertails
		private readonly ShopDBContext db = new ShopDBContext();                                                                                                                                                                                                                                                                                                                                                                                                     
		// GET: Finance
		public ActionResult DoanhThu()
        {
			double total = 0;
            var allpurchased = from all in db.OrderDetailss where all.OrderHeader.OrderStatus == SD.DaHoanThanh select all;
			foreach (var item in allpurchased)
			{
				total += item.OrderHeader.OrderTotal;
			}
			return View();
        }
		public ActionResult DonHang()
		{
			var allpurchase = from all in db.OrderHeaders select all;
			return View(allpurchase.ToList());
		}
		public ActionResult Details(int id)
		{
			var detailorder = db.OrderDetailss.Where(t=>t.OrderId==id);
			return View(detailorder.ToList());
		}

	}
}