﻿using DoanMonhoc_WebCayCanh.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DoanMonhoc_WebCayCanh.Controllers.Admin
{
    public class ProductController : Controller
	{
		// GET: Product
		private readonly ShopDBContext db = new ShopDBContext();
		public ActionResult Index()
		{
			var listProduct= from prd in db.Products select prd;
			return View(listProduct.ToList());
		}

		public ActionResult AddProduct()
		{
			return View();
		}
		[HttpPost]
		public ActionResult AddProduct(Product product)
		{
			if (ModelState.IsValid)
			{
				var x = db.TypeProducts.FirstOrDefault(t => t.IdType == product.IdType);
				if (x != null)
				{
					string FileName = Path.GetFileNameWithoutExtension(product.FileImage.FileName);
					string FileExtension = Path.GetExtension(product.FileImage.FileName);
					product.Image = FileName.Trim() + FileExtension;
					string _path = Path.Combine(Server.MapPath("~/Content/Images/"), product.Image);
					product.FileImage.SaveAs(_path);
					db.Products.Add(product);
					db.SaveChanges();
				}
				else
				{
					ViewBag.error = "Loai Cay khong ton tai";
					return View(product);
				}

			}
			return RedirectToAction("Index");
		}
		public ActionResult EditProduct(int id)
		{
			Product product = db.Products.FirstOrDefault(x => x.Id == id);
			return View(product);
		}
		[HttpPost]
		public ActionResult EditProduct(Product newproduct)
		{
			if (ModelState.IsValid)
			{
				var x = db.Products.FirstOrDefault(t => t.Id == newproduct.Id);
				if (x != null)
				{
					Product old = db.Products.FirstOrDefault(v => v.Id == newproduct.Id);
					old.NameProduct = newproduct.NameProduct;
					old.ShortDescribe = newproduct.ShortDescribe;
					old.Status = newproduct.Status;
					old.Source = newproduct.Source;
					old.Price = newproduct.Price;
					old.IdType = newproduct.IdType;

					string FileName = Path.GetFileNameWithoutExtension(newproduct.FileImage.FileName);
					string FileExtension = Path.GetExtension(newproduct.FileImage.FileName);
					newproduct.Image = FileName.Trim() + FileExtension;
					string _path = Path.Combine(Server.MapPath("~/Content/Images/"), newproduct.Image);
					newproduct.FileImage.SaveAs(_path);
					old.Image = newproduct.Image;
					old.FileImage = newproduct.FileImage;
					db.SaveChanges();
					return RedirectToAction("Index");
				}
				else
				{
					ViewBag.error = "Loai cay khong ton tai";
					return View(newproduct);
				}

			}
			return RedirectToAction("Index");
		}
		public ActionResult DeleteProduct(int id)
		{
			Product product = db.Products.FirstOrDefault(x => x.Id == id);
			db.Products.Remove(product);
			db.SaveChanges();
			return RedirectToAction("Index");
		}
	}
}